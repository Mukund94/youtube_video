import React , {Component} from "react";

class youtube extends Component{

    render(){

        return(
  <div> <div><h1> i m youtube</h1> </div>
   <div>welcome</div></div>

        );
    }
}

export default youtube;